package com.example.maheshreddidalli_calculatorapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView textViewResultFinal = findViewById(R.id.textViewResultFinal);
        Button buttonBack = findViewById(R.id.buttonBack);

        // Get the result from MainActivity
        Intent intent = getIntent();
        double result = intent.getDoubleExtra("result", 0);
        textViewResultFinal.setText(String.valueOf(result));

        // Back button functionality
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();  // Goes back to MainActivity
            }
        });
    }
}
